'use strict';

var core = require('@tauri-apps/api/core');

async function ping(value) {
    return await core.invoke('plugin:android-accessibility|ping', {
        payload: {
            value,
        },
    }).then((r) => (r.value ? r.value : null));
}
async function checkAccessibilityEnabled() {
    return await core.invoke('plugin:android-accessiblity|check_accessibility_enabled');
}
async function openAccessibilitySettings() {
    return await core.invoke('plugin:android-accessiblity|open_accessibility_settings');
}
async function getFrontmostUiTree(payload = {}) {
    return await core.invoke('plugin:android-accessiblity|get_frontmost_ui_tree', {
        payload,
    });
}
async function clickNode(payload) {
    return await core.invoke('plugin:android-accessiblity|click_node', {
        payload,
    });
}
async function performGesture(payload) {
    return await core.invoke('plugin:android-accessiblity|perform_gesture', {
        payload,
    });
}
async function performGlobalAction(payload) {
    return await core.invoke('plugin:android-accessiblity|perform_global_action', {
        payload,
    });
}
async function performNodeAction(payload) {
    return await core.invoke('plugin:android-accessiblity|perform_node_action', {
        payload,
    });
}

exports.checkAccessibilityEnabled = checkAccessibilityEnabled;
exports.clickNode = clickNode;
exports.getFrontmostUiTree = getFrontmostUiTree;
exports.openAccessibilitySettings = openAccessibilitySettings;
exports.performGesture = performGesture;
exports.performGlobalAction = performGlobalAction;
exports.performNodeAction = performNodeAction;
exports.ping = ping;
