export declare function ping(value: string): Promise<string | null>;
export interface AccessibilityPermissionStatus {
    enabled: boolean;
    serviceId: string;
    enabledServices: string[];
}
export interface Bounds {
    left: number;
    top: number;
    right: number;
    bottom: number;
}
export interface UiNode {
    nodeId: string;
    className?: string | null;
    text?: string | null;
    contentDescription?: string | null;
    resourceId?: string | null;
    packageName?: string | null;
    bounds?: Bounds | null;
    clickable: boolean;
    enabled: boolean;
    focusable: boolean;
    focused: boolean;
    scrollable: boolean;
    selected: boolean;
    checkable: boolean;
    checked: boolean;
    longClickable: boolean;
    children: UiNode[];
}
export interface UiTreeRequest {
    maxDepth?: number;
    maxChildrenPerNode?: number;
    includeNonClickable?: boolean;
}
export interface UiTreeResponse {
    timestampMs: number;
    packageName?: string | null;
    root?: UiNode | null;
}
export interface ClickNodeRequest {
    nodeId: string;
    action?: 'click' | 'longClick' | 'focus';
    fallbackToClickableParent?: boolean;
}
export interface ClickNodeResponse {
    success: boolean;
    performedOnNodeId?: string | null;
    message?: string | null;
}
export interface OpenSettingsResponse {
    opened: boolean;
}
export interface GesturePoint {
    x: number;
    y: number;
}
export interface GestureStroke {
    points: GesturePoint[];
    startTimeMs?: number;
    durationMs: number;
    willContinue?: boolean;
}
export interface PerformGestureRequest {
    strokes: GestureStroke[];
}
export interface PerformGestureResponse {
    success: boolean;
    message?: string | null;
}
export type GlobalActionType = 'back' | 'home' | 'recents' | 'notifications' | 'quickSettings' | 'powerDialog' | 'lockScreen' | 'takeScreenshot';
export interface GlobalActionRequest {
    action: GlobalActionType;
}
export interface GlobalActionResponse {
    success: boolean;
    message?: string | null;
}
export type NodeActionType = 'click' | 'longClick' | 'focus' | 'clearFocus' | 'select' | 'clearSelection' | 'scrollForward' | 'scrollBackward';
export interface NodeActionRequest {
    nodeId: string;
    action: NodeActionType;
    fallbackToScrollableParent?: boolean;
}
export interface NodeActionResponse {
    success: boolean;
    performedOnNodeId?: string | null;
    message?: string | null;
}
export declare function checkAccessibilityEnabled(): Promise<AccessibilityPermissionStatus>;
export declare function openAccessibilitySettings(): Promise<OpenSettingsResponse>;
export declare function getFrontmostUiTree(payload?: UiTreeRequest): Promise<UiTreeResponse>;
export declare function clickNode(payload: ClickNodeRequest): Promise<ClickNodeResponse>;
export declare function performGesture(payload: PerformGestureRequest): Promise<PerformGestureResponse>;
export declare function performGlobalAction(payload: GlobalActionRequest): Promise<GlobalActionResponse>;
export declare function performNodeAction(payload: NodeActionRequest): Promise<NodeActionResponse>;
